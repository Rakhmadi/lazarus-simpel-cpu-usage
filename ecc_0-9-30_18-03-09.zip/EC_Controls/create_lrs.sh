#!/bin/bash

~/Lazarus_FPC/lazarus/tools/lazres ecslider.lrs tecslider.png
~/Lazarus_FPC/lazarus/tools/lazres ecprogressbar.lrs tecprogressbar.png tecpositionbar.png tecspinposition.png
~/Lazarus_FPC/lazarus/tools/lazres ecruler.lrs tecruler.png
~/Lazarus_FPC/lazarus/tools/lazres ecspinctrls.lrs  tecspinbtns.png tecspinedit.png tectimer.png tecspincontroller.png
~/Lazarus_FPC/lazarus/tools/lazres eceditbtns.lrs teceditbtn.png teccolorbtn.png tecspeedbtn.png teccombobtn.png teccolorcombo.png
~/Lazarus_FPC/lazarus/tools/lazres ecswitch.lrs tecswitch.png fullcircle8.png zero8.png fullcircle4.png zero4.png
~/Lazarus_FPC/lazarus/tools/lazres ecimagemenu.lrs tecimagemenu.png
~/Lazarus_FPC/lazarus/tools/lazres ecgroupctrls.lrs teccheckgroup.png tecradiogroup.png
~/Lazarus_FPC/lazarus/tools/lazres ecscheme.lrs tecscheme.png
~/Lazarus_FPC/lazarus/tools/lazres ecbevel.lrs tecbevel.png
~/Lazarus_FPC/lazarus/tools/lazres eclink.lrs teclink.png
~/Lazarus_FPC/lazarus/tools/lazres ecconfcurve.lrs tecconfcurve.png
~/Lazarus_FPC/lazarus/tools/lazres ecchecklistbox.lrs tecchecklistbox.png
~/Lazarus_FPC/lazarus/tools/lazres echeader.lrs techeader.png
~/Lazarus_Qt/lazarus/tools/lazres ectabctrl.lrs tectabctrl.png addL.png closeL.png closenorm.png closeinact.png closedis.png closehigh.png
~/Lazarus_Qt/lazarus/tools/lazres ecaccordion.lrs tecaccordion.png
~/Lazarus_Qt/lazarus/tools/lazres ectriangle.lrs tectriangle.png
~/Lazarus_Qt/lazarus/tools/lazres ecgrid.lrs tecgrid.png






