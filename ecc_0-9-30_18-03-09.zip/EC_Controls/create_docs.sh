#!/bin/bash

fpdoc --format=html --package=eccontrols --descr-dir=docs \
  --input=ectypes.pas --input=ecscale.pas \
  --input=ecslider.pas --input=ecprogressbar.pas \
  --input=ecswitch.pas --input=ecruler.pas \
  --input=ecspinctrls.pas --input=eceditbtns.pas \
  --input=ecimagemenu.pas --input=ecgroupctrls.pas \
  --input=ecscheme.pas \
  --output=docs/html --dont-trim