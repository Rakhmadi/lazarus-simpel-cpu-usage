dd := test <- 20 dd := <- dd //comment
