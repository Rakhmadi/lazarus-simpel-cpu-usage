dd .- dd ~@ dd ->> dd #_(some) ;; some
#( <=dd ) dd #{dd}
