~/lazarus/tools/lazres nicescroll1.res mouse_scroll.cur=atsyn_move mouse_scroll_up.cur=atsyn_move_u mouse_scroll_down.cur=atsyn_move_d mouse_scroll_left.cur=atsyn_move_l mouse_scroll_right.cur=atsyn_move_r 
~/lazarus/tools/lazres nicescroll2.res mouse_scroll.png=atsyn_scrollmark

~/lazarus/tools/lazres editor_hourglass.res editor_hourglass.png=atsyn_wait
~/lazarus/tools/lazres editor_save.res editor_save.png=atsyn_save

~/lazarus/tools/lazres foldbar.res fold_plus.png=atsyn_fold_p fold_minus.png=atsyn_fold_m 
