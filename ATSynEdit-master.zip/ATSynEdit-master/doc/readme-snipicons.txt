Icons "hourglass", "floppy" by Snip Master
https://www.iconfinder.com/snipicons

License: Creative Commons (Attribution-Noncommercial 3.0 Unported) 
http://creativecommons.org/licenses/by-nc/3.0/
