nn::dd \\ dd <- nn..nn |> dd <= nn && nn != nn -> nn << nn >> nn === nn <> nn 
"#{test}" => nn ++ nn -- nn
