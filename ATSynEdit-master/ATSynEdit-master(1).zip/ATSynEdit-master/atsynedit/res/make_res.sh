~/lazarus/tools/lazres nicescroll1.res mouse_scroll.cur=atsyn_move mouse_scroll_up.cur=atsyn_move_u mouse_scroll_down.cur=atsyn_move_d mouse_scroll_left.cur=atsyn_move_l mouse_scroll_right.cur=atsyn_move_r 
~/lazarus/tools/lazres nicescroll2.res mouse_scroll.png=atsyn_scrollmark mouse_scroll_150.png=atsyn_scrollmark_150 mouse_scroll_200.png=atsyn_scrollmark_200

~/lazarus/tools/lazres editor_hourglass.res editor_hourglass.png=atsyn_wait editor_save.png=atsyn_save

~/lazarus/tools/lazres foldbar.res fold_plus.png=atsyn_fold_p fold_plus_150.png=atsyn_fold_p_150 fold_plus_200.png=atsyn_fold_p_200 fold_minus.png=atsyn_fold_m fold_minus_150.png=atsyn_fold_m_150 fold_minus_200.png=atsyn_fold_m_200 
