Editor control for Lazarus, alternate to SynEdit "for human beings" (Python requests). 
Implemented much. 
Implemented multi-carets from birth.

- Doc wiki: http://wiki.freepascal.org/ATSynEdit
- Adapter for SynWrite lexers: http://wiki.freepascal.org/ATSynEdit_EControl_adapter

Options:

![img](img/screen.png?raw=true)

Syntax-hilite with EControl lexers:

![img](img/syntax_pas.png?raw=true)
![img](img/syntax_cs.png?raw=true)
![img](img/syntax_css.png?raw=true)
![img](img/syntax_py.png?raw=true)

Feature called "gaps" allows to show bitmaps between lines:

![img](img/pics.png?raw=true)
